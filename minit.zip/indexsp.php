<?php
$name = $_POST['name'];
$rollno =$_POST['rollno'];
$sport = $_POST['sport'];
$gender = $_POST['gender'];
$branch = $_POST['branch'];
$section = $_POST['section'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$other = $_POST['other'];


if (!empty($name) || !empty($rollno) || !empty($sport) || !empty($gender)|| !empty($branch)|| !empty($section)|| !empty($email)|| !empty($phone)|| !empty($other)){
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "sprt";

// creating connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);	
if (mysqli_connect_error()){
	     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT email From spd Where email = ? Limit 1";
     $INSERT = "INSERT Into spd (name, rollno, sport, gender, branch, section, email, phone, other) values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
	 
//Prepare statement
$stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
	  $stmt->bind_param("sssssssss", $name, $rollno, $sport, $gender, $branch, $section, $email, $phone, $other);
	  
      $stmt->execute();
      echo "Your data is inserted sucessfully";
     } else {
      echo "Someone already register using this email";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?>